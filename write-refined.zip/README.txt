SummerDeer — refined writing page

INSTALL
1. Back up your current write.html.
2. Copy this write.html into the same SummerDeer app folder, replacing the old file.
3. Start your existing SummerDeer server if it is stopped.
4. Open the Write page through the server and refresh. On Windows, Ctrl+F5
   reloads the page if the old design still appears.

This is a replacement page, not a complete server package. It uses your existing
server, main.css, icons and other app files. Open it through SummerDeer rather
than double-clicking the HTML file.

SERVER VERSION
Your uploaded page requires SummerDeer server version 27.0.0 for publishing.
This replacement preserves that requirement. Installing this HTML does not
upgrade a V26 server.

WHAT CHANGED
The navigation, writing toolbar and save status stay in place. The story
document scrolls independently beneath them.

Format: bold, italic, headings, quotes, alignment, undo and redo.
Insert: images and text boxes.
More: author, sample and discard draft; Preview also moves here on small phones.
Public / Private: choose Publish or Save draft.

Dropdowns support keyboard navigation and Escape. Formatting retains the text
selection. Phone layouts use fewer visible buttons and keep menus within view.

CHECKED
Desktop and phone-size Chromium checks cover fixed controls, document scrolling,
dropdowns, selection, formatting, undo/redo, author, image/text-box insertion,
preview, draft persistence and publication through a compatible test server.
Keyboard opening was checked using a reduced viewport height; physical phones
and Safari were not tested.

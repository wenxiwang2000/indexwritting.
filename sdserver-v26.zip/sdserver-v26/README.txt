SummerDeer V26 — refined and tested
==================================

QUICK START
-----------
1. Extract this ZIP completely into a new folder.
2. Install Node.js 22.16 or newer (a current Node.js LTS release is recommended).
3. Run one of these:
   Windows: double-click START_SUMMERDEER.bat
   macOS: run START_SUMMERDEER.command
   Linux: run ./START_SUMMERDEER.sh
   Any platform: open a terminal in this folder and run npm start
4. Open http://127.0.0.1:3000 and keep the server terminal open.

There are no third-party runtime dependencies. npm install is not required.
If macOS does not allow double-clicking the .command file, use npm start
in Terminal, or run: bash START_SUMMERDEER.command
Do not open the HTML files directly; accounts and publishing require the server.
The double-click launchers open the browser after the correct server is ready.

UPGRADING AN EXISTING INSTALLATION
---------------------------------
Stop the old server before opening the new version.
Keep a backup of the old folder. To retain your existing accounts, stories,
images, and server drafts, copy the ENTIRE old repository folder into the new
version while both servers are stopped, replacing the bundled sample repository.
Keep the complete repository together: its database, uploads, password registry,
sessions, and users folders belong to the same installation.
The V26 ZIP retains the sample database and empty account registries from your
uploaded ZIP. Test accounts and stories are not included in the release.
If old browser pages remain visible, reload once after the new server starts.
V26 replaces only SummerDeer's old service-worker caches.

USING SUMMERDEER
---------------
Story: search, open stories, heart/double-click to like, and Save/Unsave.
Guest likes and saves stay in the current browser; account likes and saves
are stored by the server. Guest activity is not automatically imported at login.
Account: click the deer logo; register or log in with a username and password
of at least six characters. Saved and Liked include remove actions.
My Stories lists stories published while signed in, with Open, Edit, and Delete.
Log in BEFORE publishing if you want to own, edit, or delete that story later.

Write: title and author, bold/italic, headings, quotes, alignment, undo/redo,
image and box insertion, drag placement, resize, lock/unlock, preview, and Toss.
PNG, JPG, and WebP images are accepted, up to five images per draft/story.
Use Public + Publish to publish; use Private + Save Private to retain the
current draft without adding it to the public feed. Private mode retains one
current working draft, not a separate library of private stories.
Drafts save in this browser and also on the server when reachable. Restore
uses the newest saved copy. Draft access is tied to the browser's draft key;
it is not account-based cross-device synchronization.
Private save reports whether the draft was saved locally, on the server,
or could not be saved. Toss removes both saved copies when the server is online;
a failed server deletion is retained for retry when that browser reconnects.

Vision: the informational page and its navigation/theme controls are included.
Theme choice persists between pages. All pages have mobile navigation.

OFFLINE AND INSTALLATION
------------------------
After one online visit, the service worker retains the application pages,
icons, sample story images, and previously cached images. The built-in
Photographer story can be read offline, and drafts can save in browser storage.
Publishing, login, account libraries, and server-backed updates require a
running/reachable server. Published story API bodies are not cached offline.
Install/Add to Home Screen availability depends on the browser. A public
installation requires HTTPS; localhost works during development.

OPTIONAL CONFIGURATION
----------------------
PORT: default 3000. Choose another port if it is already in use.
HOST: default 127.0.0.1. For a public deployment, bind as needed behind HTTPS.
SUMMERDEER_REPOSITORY_DIR: optional absolute path for persistent app storage.
SUMMERDEER_ADMIN_TOKEN: optional moderation token. When configured, new public
stories are pending until reviewed at /admin. Their owner can still open/edit
them. Without this token, publication is immediate. Enter the token in the
Admin page; it is held for the current tab/session rather than localStorage.
SUMMERDEER_AI_URL: optional URL of your own JSON-over-HTTP AI service.
POST /api/chat forwards a JSON object to that service and returns its response.
There is no AI chat screen or bundled AI model in this project. Missing AI
configuration returns HTTP 503 with setup guidance; upstream failures return
HTTP 502. The test suite checks this integration using a local test service.
Set optional variables before starting Node; no credentials are bundled.

VERIFY
------
Run npm test in this folder. Tests use isolated temporary storage and do not
modify your actual repository data. See TEST_REPORT.txt for the checks run
for this release. Windows/macOS launchers and native PWA installation still
need their respective operating system/browser for a real-device check.

WHAT CHANGED IN V26
-------------------
- Fixed guest reader crash, unreachable image double-click liking, stale
  search results, and mobile account navigation.
- Added feed saving and library Unlike/Unsave actions, with visible failures.
- Corrected draft/save/delete races and false-success private save messages.
- Prevented restored drafts from replacing text typed during initial loading.
- Retained image data through delete/undo, and fixed box/image quota tracking.
- Preserved alignment, floating boxes, and image sizing in published stories.
- Improved request validation, account ownership, pending story access,
  account backup consistency, startup errors, and shutdown behavior.
- Bumped PWA caches, limited cache growth, and kept unrelated caches intact.
- Added repeatable API regression tests and platform-aware startup helpers.

Earlier release notes are retained in VERSION_HISTORY.txt.

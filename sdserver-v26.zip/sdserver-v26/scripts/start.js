'use strict';
const path = require('node:path');
const { spawn } = require('node:child_process');
const [major, minor] = process.versions.node.split('.').map(Number);
if (major < 22 || (major === 22 && minor < 16)) {
  console.error('SummerDeer requires Node.js 22.16 or newer. Install a current Node.js LTS release, then try again.');
  process.exit(1);
}
try { require('node:sqlite'); }
catch {
  console.error('This Node.js installation does not include SQLite. Install the official Node.js LTS release.');
  process.exit(1);
}
const root = path.join(__dirname, '..');
const version = require('../package.json').version;
const child = spawn(process.execPath, [path.join(root, 'server.js')], { cwd: root, stdio: 'inherit' });
let closed = false;
child.once('error', error => { console.error(error.message); process.exitCode = 1; closed = true; });
child.once('exit', (code, signal) => { closed = true; process.exitCode = code ?? (signal === 'SIGINT' || signal === 'SIGTERM' ? 0 : 1); });
for (const signal of ['SIGINT', 'SIGTERM']) process.on(signal, () => { if (!closed) child.kill(signal); });

if (process.argv.includes('--open')) {
  const host = process.env.HOST || '127.0.0.1';
  const browserHost = ['0.0.0.0', '::'].includes(host) ? '127.0.0.1' : host;
  const url = `http://${browserHost.includes(':') ? `[${browserHost}]` : browserHost}:${process.env.PORT || 3000}`;
  (async () => {
    const deadline = Date.now() + 15000;
    while (!closed && Date.now() < deadline) {
      try {
        const response = await fetch(url + '/api/health', { signal: AbortSignal.timeout(500) });
        const data = await response.json();
        if (response.ok && data.app === 'SummerDeer' && data.version === version) {
          if (closed) return;
          const command = process.platform === 'win32' ? 'cmd.exe' : process.platform === 'darwin' ? 'open' : 'xdg-open';
          const args = process.platform === 'win32' ? ['/c', 'start', '', url] : [url];
          const opener = spawn(command, args, { stdio: 'ignore', detached: true });
          opener.once('error', () => console.log(`Open ${url} in your browser.`));
          opener.unref();
          return;
        }
      } catch {}
      await new Promise(resolve => setTimeout(resolve, 150));
    }
    if (!closed) console.log(`Open ${url} in your browser once the server is ready.`);
  })().catch(error => console.error(error.message));
}

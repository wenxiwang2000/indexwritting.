#!/bin/bash
cd "$(dirname "$0")" || exit 1
if ! command -v node >/dev/null 2>&1; then
  echo "Node.js 22.16 or newer is required."
  read -p "Press Enter to close..."
  exit 1
fi
node scripts/start.js --open
status=$?
if [ "$status" -ne 0 ]; then
  read -r -p "Press Enter to close..."
fi
exit "$status"

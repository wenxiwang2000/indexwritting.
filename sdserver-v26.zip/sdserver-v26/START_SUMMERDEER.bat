@echo off
title SummerDeer Server
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js 22.16 or newer is required.
  echo Install Node.js, then double-click this file again.
  pause
  exit /b 1
)
node scripts\start.js --open
echo.
echo SummerDeer stopped. Keep this window open while using the website.
pause

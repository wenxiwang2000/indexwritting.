"use strict";
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { DatabaseSync } = require('node:sqlite');

const ROOT = __dirname;
const PORT = Number(process.env.PORT || 3000);
const HOST = process.env.HOST || '127.0.0.1';
const REPOSITORY_DIR = path.resolve(process.env.SUMMERDEER_REPOSITORY_DIR || path.join(ROOT, 'repository'));
const DATA_DIR = path.join(REPOSITORY_DIR, 'data');
const UPLOAD_DIR = path.join(REPOSITORY_DIR, 'uploads');
const PASSWORD_DIR = path.join(REPOSITORY_DIR, 'password');
const USERS_DIR = path.join(REPOSITORY_DIR, 'users');
const ACCOUNT_FILE = path.join(PASSWORD_DIR, 'accounts.json');
const SESSION_FILE = path.join(PASSWORD_DIR, 'sessions.json');
const ADMIN_TOKEN = String(process.env.SUMMERDEER_ADMIN_TOKEN || '').trim();
const AI_URL = String(process.env.SUMMERDEER_AI_URL || '').trim();
const APP_VERSION = require('./package.json').version;
fs.mkdirSync(DATA_DIR, { recursive: true });
fs.mkdirSync(UPLOAD_DIR, { recursive: true });
fs.mkdirSync(PASSWORD_DIR, { recursive: true });
fs.mkdirSync(USERS_DIR, { recursive: true });

// V12 repository layout. If an older V9 install has ./data or ./uploads,
// copy it into ./repository automatically the first time V10 starts.
const legacyDb = path.join(ROOT, 'data', 'summerdeer.db');
const repoDb = path.join(DATA_DIR, 'summerdeer.db');
if (!fs.existsSync(repoDb) && fs.existsSync(legacyDb)) {
  for (const suffix of ['', '-wal', '-shm']) {
    const src = legacyDb + suffix, dst = repoDb + suffix;
    if (fs.existsSync(src)) fs.copyFileSync(src, dst);
  }
}
const legacyUploads = path.join(ROOT, 'uploads');
if (fs.existsSync(legacyUploads) && legacyUploads !== UPLOAD_DIR) {
  for (const entry of fs.readdirSync(legacyUploads, { withFileTypes: true })) {
    if (!entry.isFile()) continue;
    const src = path.join(legacyUploads, entry.name);
    const dst = path.join(UPLOAD_DIR, entry.name);
    if (!fs.existsSync(dst)) fs.copyFileSync(src, dst);
  }
}

const db = new DatabaseSync(repoDb);
db.exec('PRAGMA foreign_keys = ON;');
db.exec('PRAGMA busy_timeout = 5000;');
db.exec('PRAGMA journal_mode = WAL;');
db.exec(`
CREATE TABLE IF NOT EXISTS stories (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  slug TEXT NOT NULL UNIQUE,
  title TEXT NOT NULL,
  author TEXT NOT NULL DEFAULT 'Anonymous',
  summary TEXT NOT NULL DEFAULT '',
  body TEXT NOT NULL,
  tone TEXT NOT NULL DEFAULT 'warm',
  status TEXT NOT NULL DEFAULT 'published',
  cover_image TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  owner_username TEXT NOT NULL DEFAULT ''
);
CREATE TABLE IF NOT EXISTS story_images (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  story_id INTEGER NOT NULL,
  url TEXT NOT NULL,
  original_name TEXT NOT NULL DEFAULT '',
  position INTEGER NOT NULL DEFAULT 0,
  FOREIGN KEY(story_id) REFERENCES stories(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS user_drafts (
  client_key TEXT PRIMARY KEY,
  payload TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_stories_status_created ON stories(status, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_story_images_story ON story_images(story_id, position);
CREATE TABLE IF NOT EXISTS story_reactions (
  username TEXT NOT NULL,
  story_slug TEXT NOT NULL,
  liked INTEGER NOT NULL DEFAULT 0,
  saved INTEGER NOT NULL DEFAULT 0,
  updated_at TEXT NOT NULL,
  PRIMARY KEY(username, story_slug)
);
CREATE INDEX IF NOT EXISTS idx_story_reactions_user ON story_reactions(username);
CREATE INDEX IF NOT EXISTS idx_user_drafts_updated ON user_drafts(updated_at DESC);
`);
{
  const cols = db.prepare("PRAGMA table_info(stories)").all().map(x => x.name);
  if (!cols.includes("owner_username")) db.exec("ALTER TABLE stories ADD COLUMN owner_username TEXT NOT NULL DEFAULT ''");
}



function readJsonFile(file, fallback){
  try {
    const data=JSON.parse(fs.readFileSync(file,'utf8'));
    const key=Object.keys(fallback)[0];
    if(!data || typeof data!=='object' || Array.isArray(data) || !data[key] || typeof data[key]!=='object' || Array.isArray(data[key])) throw new Error('Invalid registry');
    return data;
  } catch(e) {
    if(e.code==='ENOENT') return fallback;
    // Never replace damaged account/session data with an empty registry.
    throw new Error(`Could not read ${path.basename(file)}. Restore a valid backup before continuing.`);
  }
}
function writeJsonFile(file, data){
  const tmp=file+'.tmp';
  fs.writeFileSync(tmp, JSON.stringify(data,null,2), {mode:0o600});
  fs.renameSync(tmp,file);
  try{fs.chmodSync(file,0o600)}catch{}
}
if(!fs.existsSync(ACCOUNT_FILE)) writeJsonFile(ACCOUNT_FILE,{accounts:{}});
if(!fs.existsSync(SESSION_FILE)) writeJsonFile(SESSION_FILE,{sessions:{}});
readJsonFile(ACCOUNT_FILE,{accounts:{}});
readJsonFile(SESSION_FILE,{sessions:{}});

function cleanUsername(v){
  return typeof v==='string' ? v.trim().replace(/\s+/g,' ') : '';
}
function validUsername(v){
  const s=cleanUsername(v);
  return s.length>=6 && s.length<=40 && /^[A-Za-z0-9_. -]+$/.test(s);
}
function validPassword(v){
  return typeof v==='string' && v.length>=6 && v.length<=200;
}
function hashPassword(password,saltHex){
  const salt=Buffer.from(saltHex,'hex');
  return crypto.scryptSync(password,salt,64).toString('hex');
}
function createSession(username){
  const data=readJsonFile(SESSION_FILE,{sessions:{}});
  const token=crypto.randomBytes(32).toString('hex');
  const now=Date.now();
  data.sessions[token]={username,created_at:now,expires_at:now+30*24*60*60*1000};
  for(const [k,v] of Object.entries(data.sessions)){
    if(!v || Number(v.expires_at||0)<now) delete data.sessions[k];
  }
  writeJsonFile(SESSION_FILE,data);
  return token;
}
function parseCookies(req){
  const out=Object.create(null);
  String(req.headers.cookie||'').split(';').forEach(part=>{
    const i=part.indexOf('=');
    if(i<0)return;
    const k=part.slice(0,i).trim(),v=part.slice(i+1).trim();
    if(k){try{out[k]=decodeURIComponent(v)}catch{}}
  });
  return out;
}
function currentUser(req){
  const token=parseCookies(req).sd_session;
  if(!token)return null;
  const data=readJsonFile(SESSION_FILE,{sessions:{}});
  const s=data.sessions?.[token];
  if(!s || !Number.isFinite(Number(s.expires_at)) || Number(s.expires_at)<=Date.now() || typeof s.username!=='string') return null;
  const accounts=readJsonFile(ACCOUNT_FILE,{accounts:{}}).accounts;
  if(!Object.hasOwn(accounts,s.username.toLowerCase())) return null;
  return {username:s.username,token};
}
function sessionCookie(token,req){
  const secure=req.socket.encrypted || String(req.headers['x-forwarded-proto']||'').split(',')[0].trim()==='https';
  return `sd_session=${encodeURIComponent(token)}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${30*24*60*60}${secure?'; Secure':''}`;
}
function clearSessionCookie(){
  return 'sd_session=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0';
}


function accountFolderId(username){
  const base=cleanUsername(username).toLowerCase().replace(/[^a-z0-9._-]+/g,'_').replace(/^_+|_+$/g,'').slice(0,28)||'user';
  const tag=crypto.createHash('sha256').update(cleanUsername(username).toLowerCase()).digest('hex').slice(0,10);
  return `${base}-${tag}`;
}
function accountDir(username){
  return path.join(USERS_DIR,accountFolderId(username));
}
function ensureAccountFolder(username){
  const dir=accountDir(username);
  fs.mkdirSync(dir,{recursive:true,mode:0o700});
  return dir;
}
function syncAccountFolder(username){
  username=cleanUsername(username);
  if(!username)return false;
  // Canonical registry and database failures must still reach the caller.
  const registry=readJsonFile(ACCOUNT_FILE,{accounts:{}});
  const key=username.toLowerCase();
  const acct=Object.hasOwn(registry.accounts,key)?registry.accounts[key]:null;
  const reactions=db.prepare('SELECT story_slug, liked, saved, updated_at FROM story_reactions WHERE username = ? ORDER BY updated_at DESC').all(username);
  const stories=db.prepare('SELECT id, slug, title, status, created_at, updated_at FROM stories WHERE owner_username = ? ORDER BY created_at DESC').all(username);
  const stamp=nowISO();
  try{
    const dir=ensureAccountFolder(username);
    writeJsonFile(path.join(dir,'profile.json'),{
      username,folder_id:accountFolderId(username),created_at:acct?.created_at||null,updated_at:stamp
    });
    if(acct?.salt && acct?.password_hash){
      writeJsonFile(path.join(dir,'credentials.json'),{
        username,salt:acct.salt,password_hash:acct.password_hash,algorithm:'scrypt',updated_at:stamp
      });
    }
    writeJsonFile(path.join(dir,'library.json'),{
      liked:reactions.filter(x=>Number(x.liked)===1).map(x=>x.story_slug),
      saved:reactions.filter(x=>Number(x.saved)===1).map(x=>x.story_slug),updated_at:stamp
    });
    writeJsonFile(path.join(dir,'stories.json'),{stories,updated_at:stamp});
    return true;
  }catch{
    console.error('Could not update an account folder backup. Canonical account and database records are retained; check repository/users permissions and free space.');
    return false;
  }
}

function nowISO(){ return new Date().toISOString(); }
function slugify(value){
  return String(value || 'story').normalize('NFKD').replace(/[\u0300-\u036f]/g,'').toLowerCase()
    .replace(/[^a-z0-9]+/g,'-').replace(/^-+|-+$/g,'').slice(0,72) || 'story';
}
function uniqueSlug(title){
  const base = slugify(title); let slug = base, i = 2;
  const q = db.prepare('SELECT 1 FROM stories WHERE slug = ? LIMIT 1');
  while(q.get(slug)){ slug = `${base}-${i++}`; }
  return slug;
}
function storyPlainText(text){
  // Match only standalone layout instructions understood by the story reader.
  // Keep unknown markers and the canonical stored body unchanged.
  return String(text||'').replace(/\r/g,'').replace(/^[\t ]*\[\[(?:image:\d+(?:\|(?:left|center|right|wide))?(?:\|\d+)?|align:(?:left|center|right|justify)|box:(?:left|center|right)(?:\|\d+)?|\/(?:align|box))\]\][\t ]*$/gim,'');
}
function storyExcerpt(text){return storyPlainText(text).replace(/\s+/g,' ').trim().slice(0,180)}
function wordInfo(text){
  const words = (storyPlainText(text).match(/\S+/g) || []).length;
  return { words, read_minutes: words ? Math.max(1, Math.ceil(words / 220)) : 0 };
}
function validClientKey(value){
  return /^[A-Za-z0-9_-]{20,100}$/.test(String(value || ''));
}
function cleanDraftPayload(data){
  const images = Array.isArray(data.images) ? data.images : [];
  if(images.length>5) throw Object.assign(new Error('Draft can contain up to 5 images'),{status:400});
  const cleanImages=images.map(im=>{
    if(!im || typeof im!=='object' || Array.isArray(im) || typeof im.id!=='string' || !/^[A-Za-z0-9_-]{1,100}$/.test(im.id)) throw Object.assign(new Error('Invalid draft image'),{status:400});
    imageFromDataUrl(im.data);
    return {id:im.id,name:safeOriginalName(im.name),data:im.data};
  });
  return {
    title: String(data.title || '').slice(0,120),
    author: String(data.author || '').slice(0,80),
    summary: String(data.summary || '').slice(0,300),
    html: String(data.html || '').slice(0,180000),
    images:cleanImages,
    updatedAt: String(data.updatedAt || nowISO()).slice(0,40)
  };
}
function getImages(storyId){
  return db.prepare('SELECT url, original_name, position FROM story_images WHERE story_id = ? ORDER BY position, id').all(storyId);
}
function publicStory(row){
  if(!row) return null;
  const images = getImages(row.id); const info = wordInfo(row.body);
  return { id:row.id, slug:row.slug, title:row.title, author:row.author, summary:row.summary, body:row.body, tone:row.tone,
    status:row.status, cover_image:row.cover_image, created_at:row.created_at, updated_at:row.updated_at, owner_username:row.owner_username||'', images, ...info };
}
function seedPhotographer(){
  const exists = db.prepare('SELECT id, owner_username FROM stories WHERE slug = ?').get('photographer');
  if(exists){
    // Older versions assigned the sample to an account that did not exist.
    // Keep a real existing owner, but do not let a future registration claim it.
    const accounts=readJsonFile(ACCOUNT_FILE,{accounts:{}}).accounts;
    if(exists.owner_username==='SummerDeer' && !Object.hasOwn(accounts,'summerdeer')) db.prepare('UPDATE stories SET owner_username = ? WHERE id = ?').run('',exists.id);
    return;
  }
  const body = `“Life isn’t easy,” Couprie said slowly, his deep voice carrying a weight of sorrow that made every word feel more regretful. “Not for me, not for you, and not for anyone who never got what they wanted.”

Sofie lit a cigarette on the edge of the bed, right beside the floor-to-ceiling window that covered most of the wall. She pushed it open slightly, letting in a thin current of cold air, then looked back at him with a careless smile. “If you keep complaining, I swear I’ll throw you out of it,” she said. “And honestly, you should be grateful. Most men would wish they were half as lucky as you tonight.”

[[image:1]]

Couprie yawned and arched his back, entirely unbothered by her threat. “Sometimes,” he said, “you ought to put yourself in another girl’s shoes. Somewhere out there, plenty of them are probably lying in bed jealous of you—for having such a remarkable companion tonight.”

Sofie’s eyes narrowed, said “How dare you? Careful. You’re only giving me more reasons to throw you out of that window.” For a moment it was hard to tell whether she was joking or truly annoyed.

“Sorry, sorry,” Couprie said, raising a hand in surrender. “Forgive me. I still have work tomorrow morning, and I’d rather not crawl home at two in the morning.”

“You’re always like this,” she said. “Next time you dare behave this way, I swear I’ll throw you out myself.”

“All right, you win,” Couprie said, his voice softening. “Let’s sleep. I didn’t mean to make you angry—I just like the way your cheeks puff up when you are.” He smiled faintly. “Come on. We’ll have plenty of time to argue tomorrow.”

“Hmph.”

Sofie shut the window and snatched the quilt from Couprie, wrapping it around herself without the slightest guilt.

Couprie kept his eyes closed, determined not to admit defeat. His hand searched lazily for the quilt, once, then again, but found nothing. At last, abandoned by warmth, he could only lay one arm across his stomach and accept the cold in silence.

--- the other day ---

The other day, near the Hotel Metropole in Brussels, Belgium, you could hear arguments rising from morning until late at night.

> Einstein said, “God does not play dice.”

> Bohr answered, “Stop telling God what to do.”

If you did not know it was the Solvay Conference, you might have mistaken the whole thing for an art auction, a courtroom drama, or some strange performance.

At last, the conference was over.

In front of the Hotel Metropole, the scientists gathered in stiff coats and serious faces, still carrying the dust of arguments from the rooms behind them. Curie stood near the middle, calm and unsmiling, as if even the camera deserved discipline.

> “Remember,” someone said dryly, “we are scientists. We do not smile. This will be in books one day. Do not let them think we were joking.”

Then the photographer called out, “Quantum!”

Click.

And just like that, one of the most iconic photographs in the history of science was taken.

[[image:2]]

Life is never easy for great minds who cannot get what they want. But it is surprisingly gentle to those who do not insist on having everything. As Couprie, the photographer, I found it a great relief to stand safely outside their “great debate.”

When Couprie came home that night, Sofie was already reading the newspaper. The moment he entered, she raised it in the air and knocked her knuckle against the photograph on the front page.

“Well done!”

Couprie looked at his own work for a second, then shrugged. “Coffee won’t be cheaper tomorrow because of that.”`;
  const stamp = nowISO();
  db.exec('BEGIN');
  try {
    const result = db.prepare('INSERT INTO stories (slug,title,author,summary,body,tone,status,cover_image,created_at,updated_at,owner_username) VALUES (?,?,?,?,?,?,?,?,?,?,?)')
      .run('photographer','Photographer','SummerDeer','A quiet fictional scene that drifts from a Brussels bedroom into the famous Solvay Conference photograph.',body,'night','published','/image1.png',stamp,stamp,'');
    const id = Number(result.lastInsertRowid);
    const add = db.prepare('INSERT INTO story_images (story_id,url,original_name,position) VALUES (?,?,?,?)');
    add.run(id,'/image1.png','Night scene',1); add.run(id,'/image2.png','Solvay Conference',2);
    db.exec('COMMIT');
  } catch(e){ db.exec('ROLLBACK'); throw e; }
}
seedPhotographer();

const MIME = {'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg','.webp':'image/webp','.svg':'image/svg+xml','.ico':'image/x-icon','.json':'application/json; charset=utf-8'};
const STATIC_FILES = new Set(['Vision.html','story.html','write.html','account.html','main.css','Iconheadforweb.png','image1.png','image2.png','google5f31a5edb445ca67.html','manifest.json','pwa.js','service-worker.js','icon-192.png','icon-512.png']);
function send(res,status,body,type='text/plain; charset=utf-8',headers={}){ res.writeHead(status,{'Content-Type':type,'X-Content-Type-Options':'nosniff',...headers}); res.end(body); }
function json(res,status,obj){ send(res,status,JSON.stringify(obj), 'application/json; charset=utf-8', {'Cache-Control':'no-store'}); }
function serveFile(res,file){
  const ext=path.extname(file).toLowerCase();
  fs.readFile(file,(err,data)=>{ if(err) return send(res,404,'Not found'); const base=path.basename(file); const cache=(ext==='.html'||base==='service-worker.js')?'no-cache':'public, max-age=3600'; const extra=base==='service-worker.js'?{'Service-Worker-Allowed':'/'}:{}; send(res,200,data,MIME[ext]||'application/octet-stream',{'Cache-Control':cache,...extra}); });
}
function readJson(req,maxBytes=56*1024*1024){
  return new Promise((resolve,reject)=>{
    let total=0,chunks=[],failed=false;
    const fail=(message,status)=>{if(failed)return;failed=true;chunks=[];reject(Object.assign(new Error(message),{status}))};
    const type=String(req.headers['content-type']||'').split(';')[0].trim().toLowerCase();
    if(type && type!=='application/json'){req.resume();return fail('Use application/json for this request',415)}
    if(Number(req.headers['content-length']||0)>maxBytes){req.resume();return fail('Request too large',413)}
    req.on('data',c=>{if(failed)return;total+=c.length;if(total>maxBytes)return fail('Request too large',413);chunks.push(c)});
    req.on('end',()=>{
      if(failed)return;
      let data;
      try{data=JSON.parse(Buffer.concat(chunks).toString('utf8')||'{}')}
      catch{return fail('Invalid JSON',400)}
      if(!data || typeof data!=='object' || Array.isArray(data))return fail('JSON body must be an object',400);
      resolve(data);
    });
    req.on('aborted',()=>fail('Request was interrupted',400));
    req.on('error',()=>fail('Could not read request',400));
  });
}
function decodePath(value){
  try{return decodeURIComponent(value)}catch{throw Object.assign(new Error('Invalid URL encoding'),{status:400})}
}
function storyIdFromPath(value,prefix){
  const id=value.slice(prefix.length);
  return /^[1-9]\d*$/.test(id) && Number.isSafeInteger(Number(id))?Number(id):null;
}
function imageFromDataUrl(data){
  const m=/^data:(image\/(?:png|jpeg|webp));base64,([A-Za-z0-9+/=\r\n]+)$/.exec(String(data||''));
  if(!m) throw Object.assign(new Error('Only PNG, JPG, or WebP images are accepted'),{status:400});
  const buf=Buffer.from(m[2],'base64');
  if(!buf.length || buf.length>8*1024*1024) throw Object.assign(new Error('Each image must be 8 MB or smaller after compression'),{status:400});
  const type=m[1]; let valid=false;
  if(type==='image/png') valid=buf.length>8 && buf.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10]));
  if(type==='image/jpeg') valid=buf.length>3 && buf[0]===0xff && buf[1]===0xd8 && buf[2]===0xff;
  if(type==='image/webp') valid=buf.length>12 && buf.toString('ascii',0,4)==='RIFF' && buf.toString('ascii',8,12)==='WEBP';
  if(!valid) throw Object.assign(new Error('Image data did not match its file type'),{status:400});
  return {buf, ext:type==='image/png'?'.png':type==='image/webp'?'.webp':'.jpg'};
}
function safeOriginalName(name){ return String(name||'image').replace(/[\r\n\0]/g,'').slice(0,120); }
const submissionHits=new Map();
function rateLimit(req,scope='publish',limit=8){
  const ip=req.socket.remoteAddress||'local',key=scope+':'+ip,now=Date.now(),windowMs=10*60*1000;
  for(const [k,v] of submissionHits)if(!v.length || now-v[v.length-1]>=windowMs)submissionHits.delete(k);
  const hits=(submissionHits.get(key)||[]).filter(t=>now-t<windowMs);
  if(hits.length>=limit)return false;
  hits.push(now);submissionHits.set(key,hits);return true;
}
function tokenSafe(req){
  if(!ADMIN_TOKEN) return false; const a=Buffer.from(String(req.headers['x-admin-token']||'')),b=Buffer.from(ADMIN_TOKEN); return a.length===b.length && crypto.timingSafeEqual(a,b);
}
function deleteStory(row){
  const images=getImages(row.id);
  const affected=db.prepare('SELECT DISTINCT username FROM story_reactions WHERE story_slug = ?').all(row.slug).map(r=>r.username);
  if(row.owner_username)affected.push(row.owner_username);
  db.exec('BEGIN');
  try{
    db.prepare('DELETE FROM story_reactions WHERE story_slug = ?').run(row.slug);
    db.prepare('DELETE FROM stories WHERE id = ?').run(row.id);
    db.exec('COMMIT');
  }catch(e){db.exec('ROLLBACK');throw e}
  for(const im of images){
    if(im.url.startsWith('/uploads/') && !db.prepare('SELECT 1 FROM story_images WHERE url = ? LIMIT 1').get(im.url)){
      try{fs.unlinkSync(path.join(UPLOAD_DIR,path.basename(im.url)))}catch(e){if(e.code!=='ENOENT')console.error('Could not remove an unused story image.')}
    }
  }
  for(const username of new Set(affected))syncAccountFolder(username);
}
function adminPage(){ return `<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>SummerDeer Admin</title>
<style>body{font-family:system-ui;margin:0;background:#151b22;color:#f7f7f4}main{width:min(860px,calc(100% - 28px));margin:50px auto}.box{background:#1f2732;border:1px solid #ffffff22;border-radius:22px;padding:20px;margin:14px 0}input,button{font:inherit;border-radius:999px;padding:10px 13px;border:1px solid #ffffff22;background:#ffffff10;color:inherit}button{cursor:pointer}button:disabled{opacity:.5;cursor:wait}.row{display:flex;gap:8px;flex-wrap:wrap}.muted{color:#ffffffaa}.body{white-space:pre-wrap;line-height:1.5}figure img{max-width:100%;max-height:280px}</style></head>
<body><main><h1>SummerDeer Review</h1><div class="box"><form id="login" class="row"><input id="t" type="password" autocomplete="off" aria-label="Admin token" placeholder="Admin token" required><button id="loadButton" type="submit">Load pending</button></form><p id="status" role="status" aria-live="polite"></p></div><div id="list"></div></main>
<script>
const e=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));
const status=document.getElementById('status'),list=document.getElementById('list'),token=document.getElementById('t');
try{localStorage.removeItem('sd_admin')}catch{}
async function request(url,options={}){
  const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),15000);
  try{const r=await fetch(url,{...options,signal:controller.signal,headers:{'Content-Type':'application/json','x-admin-token':token.value,...options.headers}});const d=await r.json();if(!r.ok)throw new Error(d.error||'Request failed.');return d}finally{clearTimeout(timer)}
}
async function load(){
  const button=document.getElementById('loadButton');button.disabled=true;status.textContent='Loading pending stories…';list.innerHTML='';
  try{
    const d=await request('/api/admin/stories');
    list.innerHTML=(d.stories||[]).map(s=>'<article class="box"><h2>'+e(s.title)+'</h2><div class="muted">'+e(s.author)+' · '+e(s.created_at)+'</div><p>'+e(s.summary)+'</p><details><summary>Read full story</summary><div class="body">'+e(s.body)+'</div>'+(s.images||[]).map(im=>'<figure><img src="'+e(im.url)+'" alt="'+e(im.original_name||'Story image')+'" loading="lazy"></figure>').join('')+'</details><p class="row"><button data-id="'+s.id+'" data-action="publish">Publish</button><button data-id="'+s.id+'" data-action="reject">Reject</button></p></article>').join('')||'<div class="box muted">No pending stories.</div>';
    status.textContent=(d.stories||[]).length+' pending stories.';
  }catch(err){status.textContent=err.name==='AbortError'?'The server took too long. Try again.':err.message}finally{button.disabled=false}
}
document.getElementById('login').addEventListener('submit',event=>{event.preventDefault();load()});
list.addEventListener('click',async event=>{
  const button=event.target.closest('button[data-action]');if(!button)return;
  button.disabled=true;status.textContent='Saving review…';
  try{await request('/api/admin/story/'+button.dataset.id,{method:'POST',body:JSON.stringify({action:button.dataset.action})});await load()}
  catch(err){status.textContent=err.name==='AbortError'?'The server took too long. Try again.':err.message;button.disabled=false}
});
</script></body></html>`; }



async function handleApi(req,res,url){
  if(url.pathname==='/api/health' && req.method==='GET') return json(res,200,{ok:true,app:'SummerDeer',version:APP_VERSION,capabilities:{accounts:true,drafts:true,stories:true,moderation:!!ADMIN_TOKEN,ai:!!AI_URL}});
  if(url.pathname==='/api/account/register' && req.method==='POST'){
    if(!rateLimit(req,'register',20))return json(res,429,{error:'Too many registration attempts. Please try again later.'});
    let data; try{data=await readJson(req,1024*1024)}catch(e){return json(res,e.status||400,{error:e.message})}
    const username=cleanUsername(data.username),password=data.password;
    if(!validUsername(username)) return json(res,400,{error:'Username must be at least 6 characters and use letters, numbers, spaces, dot, underscore, or hyphen.'});
    if(!validPassword(password)) return json(res,400,{error:'Password must be 6–200 characters.'});
    const store=readJsonFile(ACCOUNT_FILE,{accounts:{}});
    const key=username.toLowerCase();
    if(Object.hasOwn(store.accounts,key)) return json(res,409,{error:'That username is already taken.'});
    const salt=crypto.randomBytes(16).toString('hex');
    Object.defineProperty(store.accounts,key,{value:{username,salt,password_hash:hashPassword(password,salt),created_at:nowISO()},enumerable:true,writable:true,configurable:true});
    writeJsonFile(ACCOUNT_FILE,store);
    syncAccountFolder(username);
    const token=createSession(username);
    return send(res,201,JSON.stringify({ok:true,user:{username,folder_id:accountFolderId(username)}}),'application/json; charset=utf-8',{'Cache-Control':'no-store','Set-Cookie':sessionCookie(token,req)});
  }
  if(url.pathname==='/api/account/login' && req.method==='POST'){
    if(!rateLimit(req,'login',40))return json(res,429,{error:'Too many login attempts. Please try again later.'});
    let data; try{data=await readJson(req,1024*1024)}catch(e){return json(res,e.status||400,{error:e.message})}
    const username=cleanUsername(data.username),password=data.password;
    if(!validUsername(username) || !validPassword(password)) return json(res,400,{error:'Username and password must each be at least 6 characters.'});
    const store=readJsonFile(ACCOUNT_FILE,{accounts:{}});
    const acct=Object.hasOwn(store.accounts,username.toLowerCase())?store.accounts[username.toLowerCase()]:null;
    if(!acct || !/^[a-f0-9]{32}$/i.test(acct.salt||'') || !/^[a-f0-9]{128}$/i.test(acct.password_hash||'')) return json(res,401,{error:'Incorrect username or password.'});
    const actual=Buffer.from(hashPassword(password,acct.salt),'hex'),expected=Buffer.from(acct.password_hash,'hex');
    if(actual.length!==expected.length || !crypto.timingSafeEqual(actual,expected)) return json(res,401,{error:'Incorrect username or password.'});
    syncAccountFolder(acct.username);
    const token=createSession(acct.username);
    return send(res,200,JSON.stringify({ok:true,user:{username:acct.username,folder_id:accountFolderId(acct.username)}}),'application/json; charset=utf-8',{'Cache-Control':'no-store','Set-Cookie':sessionCookie(token,req)});
  }
  if(url.pathname==='/api/account/logout' && req.method==='POST'){
    const u=currentUser(req);
    if(u){
      const data=readJsonFile(SESSION_FILE,{sessions:{}});
      delete data.sessions[u.token];
      writeJsonFile(SESSION_FILE,data);
    }
    return send(res,200,JSON.stringify({ok:true}),'application/json; charset=utf-8',{'Cache-Control':'no-store','Set-Cookie':clearSessionCookie()});
  }
  if(url.pathname==='/api/account/me' && req.method==='GET'){
    const u=currentUser(req);
    return json(res,200,{user:u?{username:u.username}:null});
  }
  if(url.pathname==='/api/account/stories' && req.method==='GET'){
    const u=currentUser(req); if(!u)return json(res,401,{error:'Login required'});
    const rows=db.prepare('SELECT * FROM stories WHERE owner_username = ? ORDER BY created_at DESC').all(u.username);
    return json(res,200,{stories:rows.map(publicStory)});
  }

  if(url.pathname.startsWith('/api/account/story/') && req.method==='PUT'){
    const u=currentUser(req); if(!u)return json(res,401,{error:'Login required'});
    const id=storyIdFromPath(url.pathname,'/api/account/story/');
    if(!id)return json(res,400,{error:'Bad story id'});

    const row=db.prepare('SELECT * FROM stories WHERE id = ?').get(id);
    if(!row)return json(res,404,{error:'Story not found'});
    if(String(row.owner_username||'')!==u.username)return json(res,403,{error:'You can only edit your own stories'});

    let data; try{data=await readJson(req,2*1024*1024)}catch(e){return json(res,e.status||400,{error:e.message})}
    const title=String(data.title??row.title).trim();
    const author=String(data.author??row.author).trim().slice(0,80)||u.username;
    const summary=String(data.summary??row.summary).trim().slice(0,300);
    const body=String(data.body??row.body).trim();
    const tone=['warm','night','garden','nordic','rose','ink'].includes(data.tone)?data.tone:row.tone;

    if(title.length<2 || title.length>120)return json(res,400,{error:'Title must be 2–120 characters.'});
    if(body.length<20 || body.length>120000)return json(res,400,{error:'Story must be 20–120,000 characters.'});

    db.prepare('UPDATE stories SET title = ?, author = ?, summary = ?, body = ?, tone = ?, updated_at = ? WHERE id = ?')
      .run(title,author,summary,body,tone,nowISO(),id);

    const updated=db.prepare('SELECT * FROM stories WHERE id = ?').get(id);
    syncAccountFolder(u.username);
    return json(res,200,{ok:true,story:publicStory(updated)});
  }

  if(url.pathname.startsWith('/api/account/story/') && req.method==='DELETE'){
    const u=currentUser(req); if(!u)return json(res,401,{error:'Login required'});
    const id=storyIdFromPath(url.pathname,'/api/account/story/');
    if(!id)return json(res,400,{error:'Bad story id'});
    const row=db.prepare('SELECT * FROM stories WHERE id = ?').get(id);
    if(!row)return json(res,404,{error:'Story not found'});
    if(String(row.owner_username||'')!==u.username)return json(res,403,{error:'You can only delete your own stories'});
    deleteStory(row);
    return json(res,200,{ok:true});
  }


  if(url.pathname==='/api/account/reactions' && req.method==='GET'){
    const u=currentUser(req); if(!u)return json(res,401,{error:'Login required'});
    const rows=db.prepare('SELECT story_slug, liked, saved FROM story_reactions WHERE username = ?').all(u.username);
    return json(res,200,{
      user:{username:u.username},
      liked:rows.filter(x=>Number(x.liked)===1).map(x=>x.story_slug),
      saved:rows.filter(x=>Number(x.saved)===1).map(x=>x.story_slug)
    });
  }
  if(url.pathname==='/api/account/library' && req.method==='GET'){
    const u=currentUser(req); if(!u)return json(res,401,{error:'Login required'});
    const rows=db.prepare('SELECT story_slug, liked, saved FROM story_reactions WHERE username = ?').all(u.username);
    const liked=[],saved=[];
    for(const r of rows){
      const row=db.prepare('SELECT * FROM stories WHERE slug = ? AND status = ?').get(r.story_slug,'published');
      if(!row)continue;
      const s=publicStory(row);
      const compact={id:s.id,slug:s.slug,title:s.title,author:s.author,summary:s.summary,excerpt:storyExcerpt(s.body),tone:s.tone,cover_image:s.cover_image,created_at:s.created_at,words:s.words,read_minutes:s.read_minutes};
      if(Number(r.liked)===1)liked.push(compact);
      if(Number(r.saved)===1)saved.push(compact);
    }
    return json(res,200,{liked,saved});
  }
  if(url.pathname.startsWith('/api/account/reaction/') && req.method==='POST'){
    const u=currentUser(req); if(!u)return json(res,401,{error:'Login required'});
    const slug=decodePath(url.pathname.slice('/api/account/reaction/'.length)).slice(0,120);
    const story=db.prepare('SELECT slug FROM stories WHERE slug = ? AND status = ?').get(slug,'published');
    if(!story)return json(res,404,{error:'Story not found'});
    let data; try{data=await readJson(req,1024*1024)}catch(e){return json(res,e.status||400,{error:e.message})}
    const old=db.prepare('SELECT liked, saved FROM story_reactions WHERE username = ? AND story_slug = ?').get(u.username,slug)||{liked:0,saved:0};
    const liked=typeof data.liked==='boolean'?(data.liked?1:0):Number(old.liked||0);
    const saved=typeof data.saved==='boolean'?(data.saved?1:0):Number(old.saved||0);
    if(!liked && !saved){
      db.prepare('DELETE FROM story_reactions WHERE username = ? AND story_slug = ?').run(u.username,slug);
    }else{
      db.prepare(`INSERT INTO story_reactions (username,story_slug,liked,saved,updated_at) VALUES (?,?,?,?,?)
        ON CONFLICT(username,story_slug) DO UPDATE SET liked=excluded.liked,saved=excluded.saved,updated_at=excluded.updated_at`)
        .run(u.username,slug,liked,saved,nowISO());
    }
    syncAccountFolder(u.username);
    return json(res,200,{ok:true,liked:!!liked,saved:!!saved});
  }

  if(url.pathname.startsWith('/api/draft/')){
    const clientKey = decodePath(url.pathname.slice('/api/draft/'.length));
    if(!validClientKey(clientKey)) return json(res,400,{error:'Invalid draft key'});
    if(req.method==='GET'){
      const row = db.prepare('SELECT payload, updated_at FROM user_drafts WHERE client_key = ?').get(clientKey);
      if(!row) return json(res,200,{draft:null});
      try { return json(res,200,{draft:JSON.parse(row.payload),updated_at:row.updated_at}); }
      catch { return json(res,200,{draft:null}); }
    }
    if(req.method==='POST'){
      let data; try{ data=await readJson(req,16*1024*1024); }catch(e){ return json(res,e.status||400,{error:e.message}); }
      let draft;try{draft=cleanDraftPayload(data)}catch(e){return json(res,e.status||400,{error:e.message})}
      const payload=JSON.stringify(draft);
      if(Buffer.byteLength(payload,'utf8')>14*1024*1024) return json(res,413,{error:'Draft is too large'});
      const stamp=nowISO();
      db.prepare(`INSERT INTO user_drafts (client_key,payload,updated_at) VALUES (?,?,?)
        ON CONFLICT(client_key) DO UPDATE SET payload=excluded.payload, updated_at=excluded.updated_at`).run(clientKey,payload,stamp);
      return json(res,200,{ok:true,updated_at:stamp});
    }
    if(req.method==='DELETE'){
      db.prepare('DELETE FROM user_drafts WHERE client_key = ?').run(clientKey);
      return json(res,200,{ok:true});
    }
    return json(res,405,{error:'Method not allowed'});
  }
  if(req.method==='GET' && url.pathname==='/api/stories'){
    const q=(url.searchParams.get('q')||'').trim().slice(0,100); let rows;
    if(q){ const like=`%${q}%`; rows=db.prepare('SELECT * FROM stories WHERE status = ? AND (title LIKE ? OR author LIKE ? OR summary LIKE ? OR body LIKE ?) ORDER BY created_at DESC LIMIT 100').all('published',like,like,like,like); }
    else rows=db.prepare('SELECT * FROM stories WHERE status = ? ORDER BY created_at DESC LIMIT 100').all('published');
    const stories=rows.map(r=>{const s=publicStory(r);return {id:s.id,slug:s.slug,title:s.title,author:s.author,summary:s.summary,excerpt:storyExcerpt(s.body),tone:s.tone,cover_image:s.cover_image,created_at:s.created_at,words:s.words,read_minutes:s.read_minutes}});
    return json(res,200,{stories});
  }
  if(req.method==='GET' && url.pathname.startsWith('/api/story/')){
    const slug=decodePath(url.pathname.slice('/api/story/'.length));
    const row=db.prepare('SELECT * FROM stories WHERE slug = ?').get(slug);
    if(!row || (row.status!=='published' && (!row.owner_username || currentUser(req)?.username!==row.owner_username))) return json(res,404,{error:'Story not found'});
    return json(res,200,publicStory(row));
  }
  if(req.method==='POST' && url.pathname==='/api/stories'){
    if(!rateLimit(req)) return json(res,429,{error:'Too many submissions. Please try again later.'});
    let data; try{ data=await readJson(req); }catch(e){ return json(res,e.status||400,{error:e.message}); }
    const title=String(data.title||'').trim(),author=String(data.author||'Anonymous').trim().slice(0,80)||'Anonymous',summary=String(data.summary||'').trim().slice(0,300),body=String(data.body||'').trim(),tone=['warm','night','garden','nordic','rose','ink'].includes(data.tone)?data.tone:'warm',images=Array.isArray(data.images)?data.images:[];
    if(title.length<2 || title.length>120) return json(res,400,{error:'Title must be 2–120 characters.'});
    if(body.length<20 || body.length>120000) return json(res,400,{error:'Story must be 20–120,000 characters.'});
    if(images.length>5) return json(res,400,{error:'A story can contain up to 5 images.'});
    const slug=uniqueSlug(title),stamp=nowISO(),status=ADMIN_TOKEN?'pending':'published',saved=[]; let storyId, owner='';
    try{
      const decoded=images.map((im,i)=>{if(!im || typeof im!=='object' || Array.isArray(im))throw Object.assign(new Error('Invalid story image'),{status:400});const image=imageFromDataUrl(im.data);const name=`${Date.now()}-${i+1}-${crypto.randomBytes(6).toString('hex')}${image.ext}`;const file=path.join(UPLOAD_DIR,name);fs.writeFileSync(file,image.buf,{flag:'wx'});saved.push(file);return {url:'/uploads/'+name,original_name:safeOriginalName(im.name),position:i+1}});
      db.exec('BEGIN');
      owner=currentUser(req)?.username||''; const cover=decoded[0]?.url||''; const result=db.prepare('INSERT INTO stories (slug,title,author,summary,body,tone,status,cover_image,created_at,updated_at,owner_username) VALUES (?,?,?,?,?,?,?,?,?,?,?)').run(slug,title,author,summary,body,tone,status,cover,stamp,stamp,owner);storyId=Number(result.lastInsertRowid);
      const add=db.prepare('INSERT INTO story_images (story_id,url,original_name,position) VALUES (?,?,?,?)');decoded.forEach(im=>add.run(storyId,im.url,im.original_name,im.position));db.exec('COMMIT');
    }catch(e){try{db.exec('ROLLBACK')}catch{}saved.forEach(f=>{try{fs.unlinkSync(f)}catch{}});return json(res,e.status||500,{error:e.message||'Could not save story'});}
    const story=publicStory(db.prepare('SELECT * FROM stories WHERE id = ?').get(storyId)); if(owner)syncAccountFolder(owner); return json(res,201,{ok:true,pending:status==='pending',story});
  }
  if(req.method==='POST' && url.pathname==='/api/chat'){
    let data; try{data=await readJson(req,2*1024*1024)}catch(e){return json(res,e.status||400,{error:e.message})}
    if(!AI_URL) return json(res,503,{type:'text',error:'AI service is not configured.',answer:'Start your AI service and set SUMMERDEER_AI_URL before starting server.js.'});
    if(!rateLimit(req,'chat',30))return json(res,429,{type:'text',error:'Too many AI requests. Please try again later.'});
    try{
      const r=await fetch(AI_URL,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data),signal:AbortSignal.timeout(120000)});
      if(!r.ok)return json(res,502,{type:'text',error:'The configured AI service returned an error.',answer:'Please try again after checking your AI service.'});
      if(Number(r.headers.get('content-length')||0)>2*1024*1024){await r.body?.cancel();return json(res,502,{error:'AI response is too large.'})}
      const chunks=[];let size=0;
      for await(const chunk of r.body){size+=chunk.length;if(size>2*1024*1024){await r.body.cancel().catch(()=>{});throw new Error('AI response too large')}chunks.push(Buffer.from(chunk))}
      const text=Buffer.concat(chunks).toString('utf8');
      let out;try{out=JSON.parse(text)}catch{out={type:'text',answer:text}}
      if(!out || typeof out!=='object' || Array.isArray(out))out={type:'text',answer:String(out??'')};
      if(!text.trim())return json(res,502,{error:'AI service returned an empty response.'});
      return json(res,200,out);
    }catch(e){return json(res,502,{type:'text',error:'Could not reach the configured AI service.',answer:'Please check that your AI service is running.'})}
  }
  if(url.pathname==='/api/admin/stories' && req.method==='GET'){
    if(!tokenSafe(req)) return json(res,401,{error:'Unauthorized'});const rows=db.prepare('SELECT * FROM stories WHERE status = ? ORDER BY created_at ASC').all('pending');return json(res,200,{stories:rows.map(publicStory)});
  }
  if(url.pathname.startsWith('/api/admin/story/') && req.method==='POST'){
    if(!tokenSafe(req)) return json(res,401,{error:'Unauthorized'});
    const id=storyIdFromPath(url.pathname,'/api/admin/story/');
    if(!id)return json(res,400,{error:'Bad story id'});
    let data;try{data=await readJson(req,1024*1024)}catch(e){return json(res,e.status||400,{error:e.message})}
    const row=db.prepare('SELECT * FROM stories WHERE id = ?').get(id);
    if(!row)return json(res,404,{error:'Story not found'});
    if(data.action==='publish'){
      db.prepare('UPDATE stories SET status = ?, updated_at = ? WHERE id = ?').run('published',nowISO(),id);
      if(row.owner_username)syncAccountFolder(row.owner_username);
      return json(res,200,{ok:true});
    }
    if(data.action==='reject'){deleteStory(row);return json(res,200,{ok:true})}
    return json(res,400,{error:'Unknown action'});
  }
  return json(res,404,{error:'API route not found'});
}

const server=http.createServer(async(req,res)=>{
  try{
    const url=new URL(req.url,'http://localhost');
    if(url.pathname.startsWith('/api/')) return await handleApi(req,res,url);
    if(!['GET','HEAD'].includes(req.method))return send(res,405,'Method not allowed','text/plain; charset=utf-8',{'Allow':'GET, HEAD'});
    if(url.pathname==='/health') return json(res,200,{ok:true,app:'SummerDeer',version:APP_VERSION,node:process.version,database:'sqlite',moderation:!!ADMIN_TOKEN});
    if(url.pathname==='/admin') return send(res,200,adminPage(),'text/html; charset=utf-8',{'Cache-Control':'no-store'});
    if(url.pathname.startsWith('/uploads/')){
      const decoded=decodePath(url.pathname.slice('/uploads/'.length));
      if(!decoded || decoded!==path.basename(decoded) || /[\\\0]/.test(decoded))return send(res,404,'Not found');
      const file=path.join(UPLOAD_DIR,decoded);return serveFile(res,file);
    }
    let name=url.pathname==='/'?'story.html':decodePath(url.pathname.replace(/^\//,''));
    if(!STATIC_FILES.has(name)) return send(res,404,'Not found');
    return serveFile(res,path.join(ROOT,name));
  }catch(e){
    if(!e.status)console.error('SummerDeer request failed:',e.message);
    if(!res.headersSent && !res.destroyed)return json(res,e.status||500,{error:e.status?e.message:'Server error'});
  }
});
server.on('error',error=>{
  console.error(error.code==='EADDRINUSE'?`Port ${PORT} is already in use. Stop the other server or choose a different PORT.`:`Could not start SummerDeer: ${error.message}`);
  process.exitCode=1;
});
function shutdown(){
  server.close(()=>{db.close();process.exit(0)});
  server.closeIdleConnections();
  const timer=setTimeout(()=>{server.closeAllConnections();db.close();process.exit(0)},5000);timer.unref();
}
process.once('SIGINT',shutdown);
process.once('SIGTERM',shutdown);
server.listen(PORT,HOST,()=>{
  console.log(`\nSummerDeer is running at http://${HOST}:${PORT}`);
  console.log(`Repository: ${REPOSITORY_DIR}`);
  console.log(`Database: ${path.join('repository','data','summerdeer.db')}`);
  console.log(`Uploads: ${path.join('repository','uploads')}${path.sep}`);
  console.log('Draft autosave: repository database table user_drafts');
  console.log(ADMIN_TOKEN ? 'Moderation: ON — open /admin' : 'Moderation: OFF — stories publish immediately');
  console.log('Stop with Ctrl+C\n');
});

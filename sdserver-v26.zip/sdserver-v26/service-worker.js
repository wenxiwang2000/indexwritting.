"use strict";
const CACHE_PREFIX = "summerdeer-";
const CORE_CACHE = "summerdeer-v26-core-1";
const RUNTIME_CACHE = "summerdeer-v26-runtime-1";
const RUNTIME_LIMIT = 80;
const CORE = [
  "/", "/Vision.html", "/story.html", "/account.html", "/write.html",
  "/main.css", "/pwa.js", "/manifest.json", "/Iconheadforweb.png",
  "/icon-192.png", "/icon-512.png", "/image1.png", "/image2.png"
];

self.addEventListener("install", event => {
  event.waitUntil(caches.open(CORE_CACHE).then(cache => cache.addAll(CORE)).then(() => self.skipWaiting()));
});

self.addEventListener("activate", event => {
  event.waitUntil(
    caches.keys().then(keys => Promise.all(keys.filter(k => k.startsWith(CACHE_PREFIX) && ![CORE_CACHE,RUNTIME_CACHE].includes(k)).map(k => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

async function storeRuntime(req,res){
  if(!res.ok || res.type === "opaque")return;
  try{
    const cache=await caches.open(RUNTIME_CACHE);
    await cache.put(req,res);
    const keys=await cache.keys();
    await Promise.all(keys.slice(0,Math.max(0,keys.length-RUNTIME_LIMIT)).map(key=>cache.delete(key)));
  }catch{
    // A full browser cache must not stop an otherwise successful response.
  }
}
const offline = () => new Response("SummerDeer is offline. Reconnect and try again.", {status:503,headers:{"Content-Type":"text/plain; charset=utf-8","Cache-Control":"no-store"}});

self.addEventListener("fetch", event => {
  const req = event.request;
  if (req.method !== "GET") return;
  const url = new URL(req.url);
  if (url.origin !== self.location.origin) return;

  if (url.pathname.startsWith("/api/") || url.pathname === "/health") {
    event.respondWith(fetch(req).catch(() => new Response(JSON.stringify({error:"Offline — reconnect to use server features."}), {
      status:503,
      headers:{"Content-Type":"application/json","Cache-Control":"no-store"}
    })));
    return;
  }

  if (req.mode === "navigate") {
    event.respondWith((async()=>{
      try{
        const res=await fetch(req);
        event.waitUntil(storeRuntime(req,res.clone()));
        return res;
      }catch{
        return (await caches.match(req)) || (await caches.match(url.pathname)) || (await caches.match("/story.html")) || offline();
      }
    })());
    return;
  }

  if (url.pathname.startsWith("/uploads/") || req.destination === "image") {
    event.respondWith((async()=>{
      const cached=await caches.match(req);
      if(cached)return cached;
      try{const res=await fetch(req);event.waitUntil(storeRuntime(req,res.clone()));return res}catch{return offline()}
    })());
    return;
  }

  event.respondWith((async()=>{
    const cached=await caches.match(req);
    const network=fetch(req).then(res=>{
      event.waitUntil(storeRuntime(req,res.clone()));return res;
    }).catch(()=>cached || offline());
    if(cached){event.waitUntil(network.then(()=>{}));return cached}
    return network;
  })());
});

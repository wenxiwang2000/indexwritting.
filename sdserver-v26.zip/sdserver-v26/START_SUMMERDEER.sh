#!/usr/bin/env bash
set -eu
cd "$(dirname "$0")"
if ! command -v node >/dev/null 2>&1; then
  echo "Node.js 22.16 or newer is required. Install a current Node.js LTS release."
  exit 1
fi
exec node scripts/start.js --open

(() => {
  "use strict";

  const isStandalone =
    window.matchMedia?.("(display-mode: standalone)")?.matches ||
    window.navigator.standalone === true;

  if ("serviceWorker" in navigator && window.isSecureContext) {
    const register=()=>navigator.serviceWorker.register("/service-worker.js", {scope:"/",updateViaCache:"none"}).catch(()=>{});
    if(document.readyState==="complete")register();
    else window.addEventListener("load",register,{once:true});
  }

  const storage={get(key){try{return localStorage.getItem(key)}catch{return null}},set(key,value){try{localStorage.setItem(key,value)}catch{}}};

  if (isStandalone) return;

  const FIRST_SEEN_KEY = "summerdeer_pwa_first_visit_v21";
  const DISMISSED_KEY = "summerdeer_pwa_dismissed_v21";
  const INSTALLED_KEY = "summerdeer_pwa_installed_v21";

  let installEvent = null;
  let promptShown = false;

  const now = Date.now();
  const firstSeen = Number(storage.get(FIRST_SEEN_KEY) || 0);
  if (!firstSeen) storage.set(FIRST_SEEN_KEY, String(now));

  function isInstalled(){
    return storage.get(INSTALLED_KEY) === "1";
  }

  function recentlyDismissed(){
    const t = Number(storage.get(DISMISSED_KEY) || 0);
    return t && Date.now() - t < 3 * 24 * 60 * 60 * 1000;
  }

  function removePrompt(){
    document.getElementById("sdPwaPrompt")?.remove();
  }

  function showPrompt(mode="install"){
    if (promptShown || isStandalone || isInstalled() || recentlyDismissed()) return;
    promptShown = true;

    const isIOSGuide = mode === "ios";
    const wrap = document.createElement("aside");
    wrap.id = "sdPwaPrompt";
    wrap.setAttribute("role","dialog");
    wrap.setAttribute("aria-label","Add SummerDeer to Home Screen");

    wrap.innerHTML = `
      <style>
        #sdPwaPrompt{
          position:fixed;
          left:50%;
          bottom:max(18px,env(safe-area-inset-bottom));
          transform:translateX(-50%);
          z-index:100000;
          width:min(520px,calc(100vw - 24px));
          padding:14px;
          border:1px solid rgba(255,255,255,.18);
          border-radius:24px;
          color:#f7f7f4;
          background:linear-gradient(145deg,rgba(22,27,26,.97),rgba(27,29,34,.97));
          box-shadow:0 28px 90px rgba(0,0,0,.38);
          backdrop-filter:blur(22px);
          -webkit-backdrop-filter:blur(22px);
          font-family:Inter,system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;
          animation:sdPwaEnter .28s ease both;
        }
        #sdPwaPrompt .pwa-row{display:flex;align-items:center;gap:12px}
        #sdPwaPrompt .pwa-icon{
          width:52px;height:52px;flex:0 0 52px;border-radius:16px;
          background:#fbf7ee url("/icon-192.png") center/cover no-repeat;
          box-shadow:0 10px 30px rgba(0,0,0,.20)
        }
        #sdPwaPrompt strong{display:block;font-size:.92rem;letter-spacing:-.01em}
        #sdPwaPrompt p{margin:5px 0 0;color:rgba(247,247,244,.68);font-size:.75rem;line-height:1.5}
        #sdPwaPrompt .pwa-actions{display:flex;justify-content:flex-end;gap:8px;margin-top:13px}
        #sdPwaPrompt button{
          min-height:36px;padding:0 13px;border-radius:999px;
          border:1px solid rgba(255,255,255,.14);
          background:rgba(255,255,255,.07);color:#f7f7f4;
          font:800 .7rem/1 Inter,system-ui,sans-serif;cursor:pointer
        }
        #sdPwaPrompt button.primary{
          color:#17201c;border-color:transparent;
          background:linear-gradient(135deg,#e8c982,#aee6cf)
        }
        @keyframes sdPwaEnter{
          from{opacity:0;transform:translate(-50%,14px) scale(.98)}
          to{opacity:1;transform:translate(-50%,0) scale(1)}
        }
      </style>
      <div class="pwa-row">
        <div class="pwa-icon" aria-hidden="true"></div>
        <div>
          <strong>Add SummerDeer to your Home Screen</strong>
          <p>${
            isIOSGuide
              ? "For faster access, open your browser Share menu and choose “Add to Home Screen.”"
              : "Install SummerDeer like an app for quick access to stories and writing."
          }</p>
        </div>
      </div>
      <div class="pwa-actions">
        <button type="button" data-pwa-later>Later</button>
        <button type="button" class="primary" data-pwa-install>${isIOSGuide ? "Show me how" : "Install"}</button>
      </div>`;

    document.body.appendChild(wrap);

    wrap.querySelector("[data-pwa-later]").onclick = () => {
      storage.set(DISMISSED_KEY, String(Date.now()));
      removePrompt();
    };

    wrap.querySelector("[data-pwa-install]").onclick = async () => {
      if (isIOSGuide) {
        alert("Open the browser Share menu, then choose “Add to Home Screen.”");
        storage.set(DISMISSED_KEY, String(Date.now()));
        removePrompt();
        return;
      }

      if (!installEvent) {
        storage.set(DISMISSED_KEY, String(Date.now()));
        removePrompt();
        return;
      }

      const event = installEvent;
      installEvent = null;

      try{
        await event.prompt();
        const choice = await event.userChoice;
        if (choice?.outcome === "accepted") {
          storage.set(INSTALLED_KEY, "1");
        } else {
          storage.set(DISMISSED_KEY, String(Date.now()));
        }
      }catch{
        storage.set(DISMISSED_KEY, String(Date.now()));
      }

      removePrompt();
    };
  }

  window.addEventListener("beforeinstallprompt", e => {
    e.preventDefault();
    installEvent = e;

    // First-time visitors see the reminder promptly.
    setTimeout(() => showPrompt("install"), 900);
  });

  window.addEventListener("appinstalled", () => {
    storage.set(INSTALLED_KEY, "1");
    removePrompt();
  });

  // iOS Safari does not expose beforeinstallprompt.
  const isAppleMobile = /iPhone|iPad|iPod/i.test(navigator.userAgent) || (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1);
  if (isAppleMobile) {
    setTimeout(() => showPrompt("ios"), 1200);
  }
})();

'use strict';
const { spawn } = require('node:child_process');
const { mkdtemp, rm } = require('node:fs/promises');
const { tmpdir } = require('node:os');
const path = require('node:path');
const net = require('node:net');

async function unusedPort() {
  const socket = net.createServer();
  await new Promise((resolve, reject) => { socket.once('error', reject); socket.listen(0, '127.0.0.1', resolve); });
  const port = socket.address().port;
  await new Promise(resolve => socket.close(resolve));
  return port;
}

async function startServer(options = {}) {
  const repository = options.repository || await mkdtemp(path.join(tmpdir(), 'summerdeer-test-'));
  const port = options.port || await unusedPort();
  const child = spawn(process.execPath, ['server.js'], {
    cwd: path.join(__dirname, '..'),
    env: { ...process.env, SUMMERDEER_ADMIN_TOKEN: '', SUMMERDEER_AI_URL: '', ...options.env,
      PORT: String(port), HOST: '127.0.0.1', SUMMERDEER_REPOSITORY_DIR: repository },
    stdio: ['ignore', 'pipe', 'pipe']
  });
  let output = '';
  child.stdout.on('data', chunk => { output += chunk; });
  child.stderr.on('data', chunk => { output += chunk; });
  const base = `http://127.0.0.1:${port}`;
  async function stop(remove = !options.repository) {
    if (child.exitCode === null && child.signalCode === null) {
      const ended = new Promise(resolve => child.once('exit', resolve));
      child.kill('SIGTERM');
      await ended;
    }
    if (remove) await rm(repository, { recursive: true, force: true });
  }
  for (let i = 0; i < 100; i++) {
    if (child.exitCode !== null) throw new Error(`Server exited: ${output}`);
    try {
      const response = await fetch(base + '/api/health', { signal: AbortSignal.timeout(500) });
      if (response.ok) return { base, repository, port, child, stop };
    } catch {}
    await new Promise(resolve => setTimeout(resolve, 50));
  }
  await stop();
  throw new Error(`Server failed to start: ${output}`);
}

async function api(server, route, options = {}) {
  const { cookie, data, headers = {}, ...rest } = options;
  const response = await fetch(server.base + route, {
    ...rest, headers: { ...(data !== undefined ? { 'Content-Type': 'application/json' } : {}),
      ...(cookie ? { Cookie: cookie } : {}), ...headers },
    ...(data !== undefined ? { body: JSON.stringify(data) } : {}), signal: AbortSignal.timeout(10000)
  });
  const text = await response.text();
  let body;
  try { body = JSON.parse(text); } catch { body = text; }
  return { status: response.status, body, headers: response.headers,
    cookie: response.headers.get('set-cookie')?.split(';')[0] };
}
module.exports = { startServer, api };

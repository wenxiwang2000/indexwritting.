'use strict';
const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs/promises');
const path = require('node:path');
const http = require('node:http');
const vm = require('node:vm');
const { startServer, api } = require('./helpers');
const pkg = require('../package.json');
const storyData = { title: 'SummerDeer regression story', author: 'Test writer',
  summary: 'A story created in an isolated test repository.',
  body: 'A calm morning in the garden. This story exercises publishing, editing, and account ownership.', tone: 'garden' };
const png = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+/l9sAAAAASUVORK5CYII=';

test('All shipped browser scripts parse', async () => {
  const root = path.join(__dirname, '..');
  for (const name of ['story.html', 'account.html', 'write.html', 'Vision.html']) {
    const html = await fs.readFile(path.join(root, name), 'utf8');
    const scripts = [...html.matchAll(/<script\b[^>]*>([\s\S]*?)<\/script>/gi)];
    for (const [i, match] of scripts.entries()) new vm.Script(match[1], { filename: `${name}:script${i + 1}` });
  }
  for (const name of ['pwa.js', 'service-worker.js']) new vm.Script(await fs.readFile(path.join(root, name), 'utf8'), { filename: name });
});

test('Accounts, stories, reactions, images, drafts, and persistence', async t => {
  let server = await startServer();
  t.after(() => server.stop(true));
  let cookie, otherCookie, published;
  await t.test('Health and pages are served, private files stay private', async () => {
    const health = await api(server, '/api/health');
    assert.equal(health.status, 200);
    assert.equal(health.body.version, pkg.version);
    for (const route of ['/', '/story.html', '/write.html', '/account.html', '/Vision.html', '/manifest.json', '/pwa.js', '/service-worker.js', '/icon-192.png', '/image1.png'])
      assert.equal((await api(server, route)).status, 200, route);
    for (const route of ['/server.js', '/repository/password/accounts.json', '/repository/data/summerdeer.db'])
      assert.equal((await api(server, route)).status, 404, route);
  });
  await t.test('Guest reader can open and search the seeded story', async () => {
    const story = await api(server, '/api/story/photographer');
    assert.equal(story.status, 200);
    assert.equal(story.body.images.length, 2);
    assert.ok(story.body.words > 100);
    assert.ok((await api(server, '/api/stories?q=Photographer')).body.stories.some(x => x.slug === 'photographer'));
    assert.equal((await api(server, '/api/stories?q=NoMatchingStory123')).body.stories.length, 0);
  });
  await t.test('Creating an account named SummerDeer cannot take over the sample', async () => {
    const sample = (await api(server, '/api/story/photographer')).body;
    const sampleCookie = (await api(server, '/api/account/register', { method: 'POST', data: { username: 'SummerDeer', password: 'sample-test-password' } })).cookie;
    assert.equal((await api(server, '/api/account/story/' + sample.id, { method: 'DELETE', cookie: sampleCookie })).status, 403);
    assert.equal((await api(server, '/api/story/photographer')).status, 200);
  });
  await t.test('Registration validates input and creates a signed-in account', async () => {
    assert.equal((await api(server, '/api/account/register', { method: 'POST', data: { username: 'short', password: 'pass' } })).status, 400);
    const result = await api(server, '/api/account/register', { method: 'POST', data: { username: 'StoryWriter', password: 'test-password-123' } });
    assert.equal(result.status, 201);
    cookie = result.cookie;
    assert.ok(cookie);
    assert.equal((await api(server, '/api/account/me', { cookie })).body.user.username, 'StoryWriter');
    assert.equal((await api(server, '/api/account/register', { method: 'POST', data: { username: 'storywriter', password: 'different-password' } })).status, 409);
    const account = JSON.parse(await fs.readFile(path.join(server.repository, 'password/accounts.json'), 'utf8')).accounts.storywriter;
    assert.ok(account.password_hash && account.salt);
    assert.equal(account.password, undefined);
    assert.notEqual(account.password_hash, 'test-password-123');
    const folders = await fs.readdir(path.join(server.repository, 'users'));
    const folder = folders.find(name => name.startsWith('storywriter-'));
    assert.ok(folder);
    for (const file of ['profile.json', 'credentials.json', 'library.json', 'stories.json'])
      assert.ok((await fs.stat(path.join(server.repository, 'users', folder, file))).isFile());
  });
  await t.test('Login is case insensitive and rejects wrong passwords', async () => {
    assert.equal((await api(server, '/api/account/login', { method: 'POST', data: { username: 'StoryWriter', password: 'wrong-password' } })).status, 401);
    const login = await api(server, '/api/account/login', { method: 'POST', data: { username: 'STORYWRITER', password: 'test-password-123' } });
    assert.equal(login.status, 200);
    cookie = login.cookie;
  });
  await t.test('Account publication stores ownership and uploaded images', async () => {
    const result = await api(server, '/api/stories', { method: 'POST', cookie, data: { ...storyData, images: [{ name: 'pixel.png', data: png }] } });
    assert.equal(result.status, 201);
    assert.equal(result.body.pending, false);
    published = result.body.story;
    assert.equal(published.owner_username, 'StoryWriter');
    assert.equal(published.images.length, 1);
    const image = await fetch(server.base + published.images[0].url);
    assert.equal(image.status, 200);
    assert.equal(image.headers.get('content-type'), 'image/png');
    assert.deepEqual(Buffer.from(await image.arrayBuffer()).subarray(0, 8), Buffer.from([137,80,78,71,13,10,26,10]));
    assert.ok((await api(server, '/api/account/stories', { cookie })).body.stories.some(x => x.id === published.id));
  });
  await t.test('Likes and saves appear in the account library and can be removed', async () => {
    const route = '/api/account/reaction/' + published.slug;
    assert.equal((await api(server, route, { method: 'POST', data: { liked: true } })).status, 401);
    assert.equal((await api(server, route, { method: 'POST', cookie, data: { liked: true, saved: true } })).status, 200);
    const library = (await api(server, '/api/account/library', { cookie })).body;
    assert.equal(library.liked[0].slug, published.slug);
    assert.equal(library.saved[0].slug, published.slug);
    await api(server, route, { method: 'POST', cookie, data: { liked: false } });
    assert.deepEqual((await api(server, '/api/account/reactions', { cookie })).body.liked, []);
    assert.deepEqual((await api(server, '/api/account/reactions', { cookie })).body.saved, [published.slug]);
  });
  await t.test('Only the story owner can edit or delete it', async () => {
    otherCookie = (await api(server, '/api/account/register', { method: 'POST', data: { username: 'OtherWriter', password: 'other-test-password' } })).cookie;
    const route = '/api/account/story/' + published.id;
    assert.equal((await api(server, route, { method: 'PUT', data: { title: 'Guest edit' } })).status, 401);
    assert.equal((await api(server, route, { method: 'PUT', cookie: otherCookie, data: { title: 'Other edit' } })).status, 403);
    assert.equal((await api(server, route, { method: 'DELETE', cookie: otherCookie })).status, 403);
    const edited = await api(server, route, { method: 'PUT', cookie, data: { title: 'Edited summer story', summary: 'Updated', tone: 'rose' } });
    assert.equal(edited.status, 200);
    assert.equal(edited.body.story.title, 'Edited summer story');
    assert.equal(edited.body.story.tone, 'rose');
    assert.equal((await api(server, '/api/story/' + published.slug)).body.title, 'Edited summer story');
  });
  await t.test('Private drafts save, restore, validate, and never enter the public feed', async () => {
    const route = '/api/draft/test_draft_key_1234567890';
    const data = { title: 'Private draft test', html: '<p>Not in the public feed.</p>', images: [], updatedAt: new Date().toISOString() };
    assert.equal((await api(server, route, { method: 'POST', data })).status, 200);
    assert.equal((await api(server, route)).body.draft.title, data.title);
    assert.equal((await api(server, '/api/stories?q=Private%20draft%20test')).body.stories.length, 0);
    assert.equal((await api(server, '/api/draft/short')).status, 400);
    assert.equal((await api(server, route, { method: 'POST', data: { ...data, images: Array(6).fill({}) } })).status, 400);
  });
  await t.test('Accounts, stories, reactions, and drafts survive server restart', async () => {
    const { repository, port } = server;
    await server.stop(false);
    server = await startServer({ repository, port });
    assert.equal((await api(server, '/api/account/me', { cookie })).body.user.username, 'StoryWriter');
    assert.equal((await api(server, '/api/story/' + published.slug)).body.title, 'Edited summer story');
    assert.deepEqual((await api(server, '/api/account/reactions', { cookie })).body.saved, [published.slug]);
    assert.equal((await api(server, '/api/draft/test_draft_key_1234567890')).body.draft.title, 'Private draft test');
  });
  await t.test('Deletion removes images/reactions, clearing drafts and logout work', async () => {
    assert.equal((await api(server, '/api/account/story/' + published.id, { method: 'DELETE', cookie })).status, 200);
    assert.equal((await api(server, '/api/story/' + published.slug)).status, 404);
    assert.equal((await api(server, published.images[0].url)).status, 404);
    assert.deepEqual((await api(server, '/api/account/library', { cookie })).body.saved, []);
    await api(server, '/api/draft/test_draft_key_1234567890', { method: 'DELETE' });
    assert.equal((await api(server, '/api/draft/test_draft_key_1234567890')).body.draft, null);
    assert.equal((await api(server, '/api/account/logout', { method: 'POST', cookie })).status, 200);
    assert.equal((await api(server, '/api/account/me', { cookie })).body.user, null);
  });
});

test('Guest publication and formatted excerpts work without an account', async t => {
  const server = await startServer();
  t.after(() => server.stop());
  const result = await api(server, '/api/stories', { method: 'POST', data: {
    ...storyData, title: 'Guest formatted story',
    body: '[[align:center]]\nA guest story keeps its alignment and readable text.\n[[/align]]\n\n[[image:1|left|240]]\n\n[[box:right|300]]\nA box has more story text.\n[[/box]]',
    images: [{ name: 'pixel.png', data: png }]
  } });
  assert.equal(result.status, 201);
  assert.equal(result.body.story.owner_username, '');
  assert.equal((await api(server, '/api/account/stories')).status, 401);
  const feed = await api(server, '/api/stories?q=Guest%20formatted%20story');
  assert.equal(feed.body.stories.length, 1);
  assert.doesNotMatch(feed.body.stories[0].excerpt, /\[\[(?:image|align|box|\/align|\/box)/);
  assert.ok((await api(server, '/api/story/' + result.body.story.slug)).body.body.includes('[[align:center]]'));
});

test('An unavailable backup folder does not break canonical account functions', async t => {
  const server = await startServer();
  t.after(() => server.stop());
  const registration = await api(server, '/api/account/register', { method: 'POST', data: { username: 'BackupWriter', password: 'backup-test-password' } });
  assert.equal(registration.status, 201);
  const folder = (await fs.readdir(path.join(server.repository, 'users')))[0];
  const dir = path.join(server.repository, 'users', folder);
  await fs.rm(dir, { recursive: true });
  await fs.writeFile(dir, 'Obstruct optional mirror directory for regression testing');
  const login = await api(server, '/api/account/login', { method: 'POST', data: { username: 'BackupWriter', password: 'backup-test-password' } });
  assert.equal(login.status, 200);
  const story = await api(server, '/api/stories', { method: 'POST', cookie: login.cookie, data: storyData });
  assert.equal(story.status, 201);
  assert.equal((await api(server, '/api/account/reaction/' + story.body.story.slug, { method: 'POST', cookie: login.cookie, data: { saved: true } })).status, 200);
  assert.equal((await api(server, '/api/account/library', { cookie: login.cookie })).body.saved.length, 1);
});

test('Invalid requests fail safely and leave the server usable', async t => {
  const server = await startServer();
  t.after(() => server.stop());
  for (const [name, body] of [['null', null], ['array', []], ['number', 1]]) {
    await t.test(`Reject ${name} JSON payload`, async () => {
      const result = await api(server, '/api/account/register', { method: 'POST', data: body });
      assert.equal(result.status, 400);
    });
  }
  await t.test('Reject corrupt JSON and overlarge requests', async () => {
    const bad = await api(server, '/api/account/register', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{' });
    assert.equal(bad.status, 400);
    const large = await api(server, '/api/account/register', { method: 'POST', data: { username: 'StoryWriter', password: 'x'.repeat(1024 * 1024 + 1) } });
    assert.equal(large.status, 413);
  });
  await t.test('Reject invalid image data without leaving partial stories or files', async () => {
    const result = await api(server, '/api/stories', { method: 'POST', data: { ...storyData, images: [{ data: 'data:image/png;base64,aGVsbG8=' }] } });
    assert.equal(result.status, 400);
    assert.equal((await api(server, '/api/stories')).body.stories.length, 1);
    assert.deepEqual(await fs.readdir(path.join(server.repository, 'uploads')), []);
  });
  await t.test('Malformed URL escapes and cookies do not crash the server', async () => {
    const pathResult = await api(server, '/api/story/%E0%A4');
    assert.equal(pathResult.status, 400);
    const cookieResult = await api(server, '/api/account/me', { cookie: 'sd_session=%E0%A4' });
    assert.ok([200, 400].includes(cookieResult.status));
    assert.equal((await api(server, '/api/health')).status, 200);
  });
});

test('Moderation protects pending stories and owners can still read/edit them', async t => {
  const token = 'local-test-admin-token';
  const server = await startServer({ env: { SUMMERDEER_ADMIN_TOKEN: token } });
  t.after(() => server.stop());
  const cookie = (await api(server, '/api/account/register', { method: 'POST', data: { username: 'ModeratedWriter', password: 'moderation-password' } })).cookie;
  let pending;
  await t.test('Owner can open pending story, guests cannot', async () => {
    const result = await api(server, '/api/stories', { method: 'POST', cookie, data: storyData });
    assert.equal(result.status, 201);
    assert.equal(result.body.pending, true);
    pending = result.body.story;
    assert.equal((await api(server, '/api/story/' + pending.slug)).status, 404);
    assert.equal((await api(server, '/api/story/' + pending.slug, { cookie })).status, 200);
    assert.equal((await api(server, '/api/account/story/' + pending.id, { method: 'PUT', cookie, data: { title: 'Edited pending story' } })).status, 200);
  });
  await t.test('Admin access is required, publishing makes the story visible', async () => {
    assert.equal((await api(server, '/api/admin/stories')).status, 401);
    assert.equal((await api(server, '/api/admin/stories', { headers: { 'x-admin-token': 'wrong' } })).status, 401);
    const headers = { 'x-admin-token': token };
    assert.equal((await api(server, '/api/admin/stories', { headers })).body.stories.length, 1);
    assert.equal((await api(server, '/api/admin/story/' + pending.id, { method: 'POST', headers, data: { action: 'publish' } })).status, 200);
    assert.equal((await api(server, '/api/story/' + pending.slug)).status, 200);
    await api(server, '/api/account/reaction/' + pending.slug, { method: 'POST', cookie, data: { saved: true } });
    assert.equal((await api(server, '/api/admin/story/' + pending.id, { method: 'POST', headers, data: { action: 'reject' } })).status, 200);
    assert.equal((await api(server, '/api/story/' + pending.slug)).status, 404);
    assert.deepEqual((await api(server, '/api/account/reactions', { cookie })).body.saved, []);
  });
});

test('Optional AI endpoint reports configuration needs and forwards configured requests', async t => {
  const plain = await startServer();
  t.after(() => plain.stop());
  const unavailable = await api(plain, '/api/chat', { method: 'POST', data: { message: 'Hello' } });
  assert.equal(unavailable.status, 503);
  assert.match(unavailable.body.error, /not configured/i);
  assert.match(unavailable.body.answer, /SUMMERDEER_AI_URL/);
  let received;
  const mock = http.createServer(async (req, res) => {
    let text = '';
    for await (const chunk of req) text += chunk;
    received = JSON.parse(text);
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ type: 'text', answer: 'Response from configured test service' }));
  });
  await new Promise(resolve => mock.listen(0, '127.0.0.1', resolve));
  t.after(() => new Promise(resolve => mock.close(resolve)));
  const configured = await startServer({ env: { SUMMERDEER_AI_URL: `http://127.0.0.1:${mock.address().port}/chat` } });
  t.after(() => configured.stop());
  const reply = await api(configured, '/api/chat', { method: 'POST', data: { message: 'Hello service' } });
  assert.equal(reply.status, 200);
  assert.deepEqual(received, { message: 'Hello service' });
  assert.equal(reply.body.answer, 'Response from configured test service');
});
